
import React from 'react';

export const Loader: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[100] bg-[#050505] flex flex-col items-center justify-center">
      <div className="w-24 h-[1px] bg-white/10 relative overflow-hidden mb-8">
        <div className="absolute inset-0 bg-white w-full animate-loader-progress" />
      </div>
      <p className="text-[10px] tracking-[1em] uppercase opacity-40 animate-pulse text-white">Initializing Identity</p>
      
      <style>{`
        @keyframes loader-progress {
          0% { transform: translateX(-100%); }
          50% { transform: translateX(0); }
          100% { transform: translateX(100%); }
        }
        .animate-loader-progress {
          animation: loader-progress 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};
