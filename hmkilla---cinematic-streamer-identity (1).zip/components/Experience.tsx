
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Environment, ContactShadows, Sparkles, useScroll } from '@react-three/drei';
import * as THREE from 'three';
import { HeroModel } from './HeroModel';
import { Background } from './Background';

const AmbientLight = 'ambientLight' as any;
const HemisphereLight = 'hemisphereLight' as any;
const DirectionalLight = 'directionalLight' as any;
const SpotLight = 'spotLight' as any;
const PointLight = 'pointLight' as any;

export const Experience: React.FC = () => {
  const scroll = useScroll();
  const lastOffset = useRef(0);
  const velocity = useRef(0);

  useFrame((state) => {
    const currentOffset = scroll.offset;
    velocity.current = THREE.MathUtils.lerp(velocity.current, (currentOffset - lastOffset.current) * 15, 0.1);
    lastOffset.current = currentOffset;

    const baseFov = 35;
    const fovStretch = Math.abs(velocity.current) * 30;
    state.camera.fov = THREE.MathUtils.lerp(state.camera.fov, baseFov + fovStretch, 0.08);
    state.camera.updateProjectionMatrix();

    const progressBar = document.getElementById('scroll-progress-bar');
    if (progressBar) progressBar.style.width = `${currentOffset * 100}%`;

    const targetY = (state.mouse.y * 0.2) - (velocity.current * 0.25);
    state.camera.position.x = THREE.MathUtils.lerp(state.camera.position.x, state.mouse.x * 0.4, 0.05);
    state.camera.position.y = THREE.MathUtils.lerp(state.camera.position.y, targetY, 0.05);
    state.camera.lookAt(0, 0, 0);
  });

  return (
    <>
      <AmbientLight intensity={0.2} />
      <HemisphereLight intensity={0.3} groundColor="#000000" color="#ff0000" />
      
      <DirectionalLight 
        position={[10, 10, 10]} 
        intensity={2.5} 
        color="#ffffff"
        castShadow
      />
      
      <SpotLight 
        position={[-10, 10, -10]} 
        angle={0.6} 
        penumbra={1} 
        intensity={30} 
        color="#ff0000"
      />
      
      <PointLight position={[5, -5, 5]} intensity={5} color="#440000" />
      
      <Environment preset="night" />
      
      <Sparkles 
        count={80}
        scale={20}
        size={1.2}
        speed={0.2}
        opacity={0.15}
        color="#ff0000"
      />

      <Background />
      <HeroModel />

      <ContactShadows 
        position={[0, -4.5, 0]} 
        opacity={0.8} 
        scale={15} 
        blur={2} 
        far={10} 
        color="#200000"
      />
    </>
  );
};
