
import React, { useRef, useMemo, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useScroll, useGLTF, Center } from '@react-three/drei';
import * as THREE from 'three';

// Fix: Define intrinsic elements as local constants to bypass JSX.IntrinsicElements type checks
const Group = 'group' as any;
const Primitive = 'primitive' as any;

export const HeroModel: React.FC = () => {
  const scroll = useScroll();
  const groupRef = useRef<THREE.Group>(null);
  const meshRefs = useRef<THREE.Mesh[]>([]);
  
  const { scene } = useGLTF('components/Killa.glb');
  const model = useMemo(() => scene.clone(), [scene]);

  useEffect(() => {
    const meshes: THREE.Mesh[] = [];
    model.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        const mesh = child as THREE.Mesh;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        if (mesh.material) {
          const mat = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
          mat.forEach(m => {
            m.side = THREE.DoubleSide;
            if ('emissive' in m) (m as any).emissiveIntensity = 1.0;
          });
        }
        meshes.push(mesh);
      }
    });
    meshRefs.current = meshes;
  }, [model]);

  // Orientation Constants
  const FRONT_ORIENTATION = Math.PI * 1.5;

  // Kinetic state
  const lastOffset = useRef(0);
  const rotationVelocity = useRef(0);
  const currentRotation = useRef(FRONT_ORIENTATION); 

  useFrame((state) => {
    if (!groupRef.current) return;

    const time = state.clock.getElapsedTime();
    const offset = scroll.offset;
    
    // 1. INPUT TORQUE FROM SCROLL
    const scrollDelta = offset - lastOffset.current;
    lastOffset.current = offset;
    
    // Sensitivity for initial spin
    const sensitivity = 0.6;
    rotationVelocity.current += scrollDelta * sensitivity; 
    
    // 2. DYNAMIC PHYSICS ZONES
    const snapRegion = 0.15; // 15% of scroll at ends
    let friction = 0.88; // Base friction
    let magneticPull = 0;
    let target = currentRotation.current;

    if (offset < snapRegion) {
      // Top Zone: Pull towards base orientation
      const strength = 1.0 - (offset / snapRegion);
      target = FRONT_ORIENTATION;
      magneticPull = strength * 0.015;
      friction = THREE.MathUtils.lerp(0.88, 0.7, strength); // Get "heavier" at top
    } else if (offset > (1.0 - snapRegion)) {
      // Bottom Zone: Pull towards nearest front-facing multiple of 2PI
      const strength = (offset - (1.0 - snapRegion)) / snapRegion;
      const nearestFullRot = Math.round((currentRotation.current - FRONT_ORIENTATION) / (Math.PI * 2));
      target = FRONT_ORIENTATION + (nearestFullRot * Math.PI * 2);
      magneticPull = strength * 0.015;
      friction = THREE.MathUtils.lerp(0.88, 0.7, strength); // Get "heavier" at bottom
    }

    // Apply Dynamic Friction
    rotationVelocity.current *= friction;

    // Apply Magnetic Correction (The "Snap")
    // Instead of setting rotation, we add a velocity nudge towards the target
    const angleDiff = target - currentRotation.current;
    rotationVelocity.current += angleDiff * magneticPull;

    // 3. DRIFT & INTEGRATION
    // Drift fades out as we hit the magnetic zones to prevent "wobble"
    const driftAttenuation = 1.0 - Math.min(1.0, magneticPull * 50.0);
    const drift = 0.0018 * driftAttenuation;
    
    currentRotation.current += rotationVelocity.current + drift;
    
    // Final axial rotation
    groupRef.current.rotation.y = currentRotation.current;
    groupRef.current.rotation.x = 0;
    groupRef.current.rotation.z = 0;

    // 4. SECONDARY MOTION (Floating & Mouse)
    const hover = Math.sin(time * 0.4) * 0.02;
    const mouseInfluence = (1.0 - (magneticPull * 2.0)); // Less mouse control in snap zones
    const mouseX = state.mouse.x * 0.1 * mouseInfluence;
    const mouseY = state.mouse.y * 0.03 * mouseInfluence;

    // 5. RESPONSIVE LAYOUT
    let targetX = 0;
    let targetY = -0.75;
    let targetScale = 3.2;
    const finalScale = 3.8;

    if (offset < 0.25) {
      targetX = THREE.MathUtils.lerp(0, -2.5, offset / 0.25);
    } else if (offset < 0.5) {
      targetX = THREE.MathUtils.lerp(-2.5, 2.5, (offset - 0.25) / 0.25);
    } else if (offset < 0.75) {
      targetX = THREE.MathUtils.lerp(2.5, 0, (offset - 0.5) / 0.25);
      targetScale = THREE.MathUtils.lerp(3.2, finalScale, (offset - 0.5) / 0.25);
      targetY = THREE.MathUtils.lerp(-0.75, -0.4, (offset - 0.5) / 0.25);
    } else {
      targetScale = finalScale;
      targetY = -0.4;
    }

    groupRef.current.position.x = THREE.MathUtils.lerp(groupRef.current.position.x, targetX + mouseX, 0.05);
    groupRef.current.position.y = THREE.MathUtils.lerp(groupRef.current.position.y, targetY + hover + mouseY, 0.05);
    
    const s = THREE.MathUtils.lerp(groupRef.current.scale.x, targetScale, 0.05);
    groupRef.current.scale.set(s, s, s);

    // 6. REACTIVE EMISSIVE (Glow with spin speed)
    const spinIntensity = Math.abs(rotationVelocity.current) * 65.0;
    const flicker = Math.random() * 0.05;
    const powerLevel = 1.0 + spinIntensity + flicker;
    
    meshRefs.current.forEach(mesh => {
      if (mesh.material) {
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        mats.forEach(m => {
          if ('emissiveIntensity' in m) (m as any).emissiveIntensity = powerLevel;
        });
      }
    });
  });

  return (
    <Group ref={groupRef}>
      <Center>
        <Primitive object={model} dispose={null} />
      </Center>
    </Group>
  );
};

useGLTF.preload('components/Killa.glb');
