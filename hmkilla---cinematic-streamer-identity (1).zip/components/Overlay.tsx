
import React from 'react';

export const Overlay: React.FC = () => {
  return (
    <div className="w-full text-white">
      {/* Section 0: Hero Intro */}
      <section className="h-screen w-full flex flex-col items-center justify-center relative p-8">
        <div className="max-w-4xl text-center">
          <h1 className="text-6xl md:text-8xl font-bold mb-4 leading-none tracking-tighter">
            HMKILLA
          </h1>
          <p className="text-sm md:text-lg opacity-60 tracking-[0.3em] font-light uppercase">
            Streamer, Gamer, Lover ;)
          </p>
        </div>
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4">
          <span className="text-[10px] uppercase tracking-[0.5em] opacity-40">Scroll to explore</span>
          <div className="w-[1px] h-12 bg-white opacity-20" />
        </div>
      </section>

      {/* Section 1: About Me */}
      <section className="h-screen w-full flex items-center justify-end p-8 md:p-24">
        <div className="max-w-xl text-right">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">About me</h2>
          <div className="text-sm md:text-base leading-relaxed opacity-70 mb-8 font-light uppercase tracking-wider">
            <p className="mb-2 text-white font-bold">Hey Peeps! KILLA-KUN Here!</p>
            <p className="mb-4">Lets Keep it Short!</p>
            <p className="mb-1 text-red-500 font-bold">HYPEMAN / THEORIST / GOD GAMER</p>
            <p className="mb-4 text-red-500 font-bold">WILDMETAL VTUBER</p>
            <p className="mb-6 lowercase italic">Lover of Zelda, Kingdom Hearts, Smash Bros, Nintendo, Anime, Japan, Music & 2D Women</p>
            <p className="text-lg md:text-xl font-bold tracking-[0.5em] text-white">Let's PUNK!</p>
          </div>
          <div className="h-[2px] w-full bg-white/10 relative">
            <div className="absolute top-0 right-0 h-full w-1/3 bg-white/40" />
          </div>
        </div>
      </section>

      {/* Section 2: Subscribe */}
      <section className="h-screen w-full flex items-center justify-start p-8 md:p-24">
        <div className="max-w-lg">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">subscribe</h2>
          <div className="text-sm md:text-base leading-relaxed opacity-70 mb-8 space-y-4">
            <p>Not only does it support me and channel, but you get awesome perks such as...</p>
            <ul className="space-y-2 border-l border-red-900/40 pl-4 font-light">
              <li>*Exclusive Features in the HMK Discord Server!</li>
              <li>*Priority and Sub only Game Nights and Streams!</li>
              <li>*Monthly Movie Nights ONLY for Subs!</li>
              <li>*Sponsoring The 5th Dimension Streams</li>
              <li>*A Virtual Bro Hug or Fist Bump (While supplies last)</li>
            </ul>
          </div>
          <div className="h-[2px] w-full bg-white/10 relative">
            <div className="absolute top-0 left-0 h-full w-2/3 bg-white/40" />
          </div>
        </div>
      </section>

      {/* Section 3: Connection */}
      <section className="h-screen w-full flex flex-col items-center justify-center p-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-6xl font-bold mb-8 tracking-tighter">Socials</h2>
          <div className="flex flex-wrap justify-center gap-4">
            <SocialButton platform="Twitch" handle="@hmkilla" color="bg-purple-600" url="https://www.twitch.tv/hmkilla" />
            <SocialButton platform="YouTube" handle="hmkilla" color="bg-red-600" url="https://www.youtube.com/hmkilla" />
            <SocialButton platform="Discord" handle="The 5th Dimension" color="bg-indigo-600" url="https://discord.com/invite/hmkilla" />
          </div>
        </div>
        <div className="mt-24 opacity-30 hover:opacity-100 transition-opacity cursor-pointer text-center">
          <p className="text-[10px] tracking-[0.4em] uppercase">Business inquiries - HMKilla@live.com</p>
        </div>
      </section>
    </div>
  );
};

const SocialButton = ({ platform, handle, color, url }: { platform: string, handle: string, color: string, url: string }) => (
  <a 
    href={url} 
    target={url !== "#" ? "_blank" : undefined} 
    rel={url !== "#" ? "noopener noreferrer" : undefined}
    className="group flex flex-col items-center p-6 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 hover:scale-105 transition-all w-40"
  >
    <span className="text-[10px] uppercase tracking-widest opacity-40 mb-1">{platform}</span>
    <span className="text-xs font-bold">{handle}</span>
    <div className={`mt-4 w-1 h-1 rounded-full ${color} opacity-0 group-hover:opacity-100 group-hover:scale-[10] transition-all duration-500`} />
  </a>
);
