
import React, { useEffect, useRef, useState } from 'react';

export const CustomCursor: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const targetPos = useRef({ x: 0, y: 0 });
  const smoothedPos = useRef({ x: 0, y: 0 });
  const lastSmoothedPos = useRef({ x: 0, y: 0 });
  const velocity = useRef({ x: 0, y: 0 });
  const speed = useRef(0);
  
  const vertices = useRef([
    { x: 0, y: 0, vx: 0, vy: 0, tx: 0, ty: -12, mass: 1 },
    { x: 0, y: 0, vx: 0, vy: 0, tx: -8, ty: 8, mass: 1.2 },
    { x: 0, y: 0, vx: 0, vy: 0, tx: 8, ty: 8, mass: 1.2 },
  ]);

  const [isHovering, setIsHovering] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      targetPos.current = { x: e.clientX, y: e.clientY };
      if (!isVisible) setIsVisible(true);
    };

    const onMouseDown = () => setIsClicking(true);
    const onMouseUp = () => setIsClicking(false);

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const isPointer = window.getComputedStyle(target).cursor === 'pointer' || 
                        target.closest('button') || 
                        target.closest('a');
      setIsHovering(!!isPointer);
    };

    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mouseover', handleMouseOver);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', resize);
    resize();

    let rafId: number;
    let rotation = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      smoothedPos.current.x += (targetPos.current.x - smoothedPos.current.x) * 0.2;
      smoothedPos.current.y += (targetPos.current.y - smoothedPos.current.y) * 0.2;

      velocity.current = {
        x: smoothedPos.current.x - lastSmoothedPos.current.x,
        y: smoothedPos.current.y - lastSmoothedPos.current.y
      };
      lastSmoothedPos.current = { ...smoothedPos.current };
      speed.current = Math.sqrt(velocity.current.x ** 2 + velocity.current.y ** 2);

      if (speed.current > 0.5) {
        const targetRotation = Math.atan2(velocity.current.y, velocity.current.x) + Math.PI / 2;
        let diff = targetRotation - rotation;
        while (diff < -Math.PI) diff += Math.PI * 2;
        while (diff > Math.PI) diff -= Math.PI * 2;
        rotation += diff * 0.15;
      } else {
        rotation += 0.015;
      }

      vertices.current.forEach((v, i) => {
        let tx = v.tx;
        let ty = v.ty;
        if (isHovering) {
            const angle = (i / vertices.current.length) * Math.PI * 2 - Math.PI / 2;
            const radius = 18;
            tx = Math.cos(angle) * radius;
            ty = Math.sin(angle) * radius;
        }
        const stretchAmount = speed.current * 0.6;
        if (i === 0) ty -= stretchAmount;
        if (i > 0) ty += stretchAmount * 0.2;

        const spring = 0.12;
        const damping = 0.75;
        const ax = (tx - v.x) * spring;
        const ay = (ty - v.y) * spring;
        v.vx += ax;
        v.vy += ay;
        v.vx *= damping;
        v.vy *= damping;
        v.x += v.vx;
        v.y += v.vy;
      });

      ctx.save();
      ctx.translate(smoothedPos.current.x, smoothedPos.current.y);
      ctx.rotate(rotation);
      const masterScale = isClicking ? 0.75 : (isHovering ? 1.15 : 1.0);
      ctx.scale(masterScale, masterScale);

      const glowAlpha = isHovering ? 0.2 : 0.1;
      const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, 35);
      grad.addColorStop(0, `rgba(0, 242, 255, ${glowAlpha})`);
      grad.addColorStop(1, 'rgba(0, 242, 255, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(0, 0, 35, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.moveTo(vertices.current[0].x, vertices.current[0].y);
      for (let i = 1; i < vertices.current.length; i++) {
        ctx.lineTo(vertices.current[i].x, vertices.current[i].y);
      }
      ctx.closePath();
      ctx.strokeStyle = isHovering ? '#fff' : '#00f2ff';
      ctx.lineWidth = 1.5;
      ctx.lineJoin = 'round';
      ctx.stroke();

      if (isHovering) {
        ctx.fillStyle = 'rgba(0, 242, 255, 0.15)';
        ctx.fill();
      }

      vertices.current.forEach(v => {
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(v.x, v.y, isHovering ? 1 : 1.5, 0, Math.PI * 2);
        ctx.fill();
      });

      ctx.restore();

      if (!isClicking) {
        ctx.font = '8px "Syncopate"';
        ctx.letterSpacing = '1px';
        ctx.textAlign = 'left';
        const textX = smoothedPos.current.x + 25;
        const textY = smoothedPos.current.y;
        const label = isHovering ? '::ACCESS_POINT' : '::IDLE_MODE';
        ctx.fillStyle = isHovering ? '#fff' : 'rgba(0, 242, 255, 0.4)';
        ctx.fillText(label, textX, textY - 2);
        const posX = Math.round(targetPos.current.x).toString().padStart(4, '0');
        const posY = Math.round(targetPos.current.y).toString().padStart(4, '0');
        ctx.fillStyle = 'rgba(0, 242, 255, 0.2)';
        ctx.fillText(`${posX}.${posY}`, textX, textY + 10);
      }

      rafId = requestAnimationFrame(render);
    };
    render();
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mouseover', handleMouseOver);
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(rafId);
    };
  }, [isVisible, isHovering, isClicking]);

  if (!isVisible) return null;
  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-[9999]"
      style={{ mixBlendMode: 'screen' }}
    />
  );
};
