
import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { ScrollControls, Scroll } from '@react-three/drei';
import { Experience } from './components/Experience';
import { Overlay } from './components/Overlay';
import { Loader } from './components/Loader';
import { CustomCursor } from './components/CustomCursor';

function App() {
  return (
    <div className="h-screen w-full bg-[#050505] overflow-hidden">
      {/* Custom Interactive Cursor */}
      <CustomCursor />

      {/* Cinematic Progress Line */}
      <div className="fixed top-0 left-0 w-full h-[2px] bg-red-950/20 z-[60]">
        <div id="scroll-progress-bar" className="h-full bg-red-600 w-0 transition-all duration-100 ease-out shadow-[0_0_10px_rgba(255,0,0,0.5)]" />
      </div>

      <Suspense fallback={<Loader />}>
        <Canvas
          shadows
          camera={{ position: [0, 0, 5], fov: 35 }}
          gl={{ 
            antialias: true, 
            alpha: true,
            powerPreference: "high-performance"
          }}
          dpr={[1, 2]}
        >
          <ScrollControls pages={4} damping={0.15}>
            <Experience />
            <Scroll html>
              <Overlay />
            </Scroll>
          </ScrollControls>
        </Canvas>
      </Suspense>

      {/* Persistent Navigation */}
      <nav className="fixed top-0 left-0 w-full p-8 flex justify-between items-center z-50 pointer-events-none">
        <div className="text-xl font-bold tracking-tighter text-white pointer-events-auto cursor-pointer mix-blend-difference">
          HMKILLA.
        </div>
        {/* CENTERED ON MOBILE: using absolute positioning, RIGHT-ALIGNED ON DESKTOP: using relative positioning */}
        <div className="text-[10px] uppercase tracking-[0.5em] text-white/40 font-medium pointer-events-auto select-none absolute left-1/2 -translate-x-1/2 md:relative md:left-auto md:translate-x-0 whitespace-nowrap">
          scroll to explore
        </div>
      </nav>

      {/* Status Footer */}
      <div className="fixed bottom-0 left-0 w-full p-8 flex justify-between items-end z-50 pointer-events-none">
        <div className="max-w-xs pointer-events-auto">
          <p className="text-[10px] uppercase tracking-[0.2em] text-white/40 mb-2">Current Status</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-600 animate-pulse shadow-[0_0_8px_rgba(255,0,0,0.8)]" />
            <span className="text-xs font-medium uppercase tracking-wider text-white">LIVE..MAYBE</span>
          </div>
        </div>
        <a 
          href="https://www.twitch.tv/hmkilla"
          target="_blank"
          rel="noopener noreferrer"
          className="group relative px-8 py-3 bg-white text-black text-xs font-bold uppercase tracking-widest rounded-full overflow-hidden transition-all hover:scale-105 pointer-events-auto inline-block"
        >
          <span className="relative z-10">watch me</span>
          <div className="absolute inset-0 bg-red-600 scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500 opacity-20" />
        </a>
      </div>
    </div>
  );
}

export default App;
